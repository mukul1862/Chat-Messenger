package chat.messenger;

import java.io.*;
import java.lang.*;
import java.net.*;
import java.util.*;

public class ChatServer {
    public static Socket[] clients = new Socket[2];
    
    public static void main(String []arg) throws Exception{
        try{
            ServerSocket SERVER = new ServerSocket(9999);
            System.out.println("Waiting for clients...");
        
            for(int i=0;i<2;i++){
                Socket SOCK=SERVER.accept();
                clients[i]=(Socket)SOCK;
            
                ChatServerReturn chat=new ChatServerReturn(SOCK);
                Thread X=new Thread(chat);
                X.start();
            }
        }
        catch(Exception X){
            System.out.print(X);
        }
    }
}
