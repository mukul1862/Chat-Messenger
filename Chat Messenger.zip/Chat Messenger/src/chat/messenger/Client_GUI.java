package chat.messenger;

import java.awt.Color;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.net.*;

public class Client_GUI implements ActionListener,MouseListener {
    public static String username;
    AChatClient chatclient;
    public static JFrame jf;
    public static JPanel jp;
    public static JButton jb;
    public static JTextArea jt;
    public static JTextField jtf;
    
    Client_GUI(){
        username=JOptionPane.showInputDialog(null,"Enter Your Username","Anonymous");
        jf=new JFrame(username+"'s CHAT");
        jp=new JPanel();
        jt=new JTextArea(30,28);
        jtf=new JTextField("Type your message",25);
        jb=new JButton("SEND");
        jf.add(jp);
        jp.add(jt);
        jp.add(jtf);
        jp.add(jb);
        jt.setBounds(20, 20, 380, 480);
        jtf.setBounds(20, 510, 290, 30);
        jb.setBounds(320, 510, 80, 30);
        //jt1.setBackground(new Color(255,255,204));
        jb.addActionListener(this);
        jtf.addMouseListener(this);        
        jp.setLayout(null);
        jf.setVisible(true);
        jf.setSize(420,600);
        jf.setLocation(400,80);
        //jf.setResizable(false);
        jb.requestFocusInWindow();
        connect();
    }
    public void actionPerformed(ActionEvent e){
        chatclient.SEND(jtf.getText());
        jtf.setText("");        
        jtf.requestFocusInWindow();
    }
    public void mouseClicked(MouseEvent e){
        jtf.setText("");
        jtf.requestFocusInWindow();    
    }
    public void mouseExited(MouseEvent e){
    }
    public void mousePressed(MouseEvent e){
    }
    public void mouseReleased(MouseEvent e){
    }
    public void mouseEntered(MouseEvent e){
    }
    public void connect(){
        try{
            Socket SOCK=new Socket("localhost",9999);
            chatclient = new AChatClient(SOCK);
            System.out.println("Client Connected");
             
            Thread X=new Thread(chatclient);
            X.start();
        }
        catch(Exception X){
            System.out.print(X);
        }
    }
}
class main{
    public static void main(String[] args) {
        Client_GUI cg = new Client_GUI();
    }
}    