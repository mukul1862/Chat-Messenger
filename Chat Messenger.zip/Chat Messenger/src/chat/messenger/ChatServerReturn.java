package chat.messenger;

import java.io.*;
import java.lang.*;
import java.net.*;
import java.util.*;

public class ChatServerReturn implements Runnable{
    Socket SOCK;
    Scanner INPUT;
    PrintWriter OUT;
    String MESSAGE;
    
    public ChatServerReturn(Socket X){
        this.SOCK=X;
    }
    
    public void run(){
        try{
            try{
                INPUT=new Scanner(SOCK.getInputStream());
                OUT=new PrintWriter(SOCK.getOutputStream());
                
                while(true){
                    if(!INPUT.hasNext()){
                        return;
                    }
                    MESSAGE = INPUT.nextLine();
                    
                    for(int i=0;i<2;i++){
                        Socket TMP_SOCK =(Socket)ChatServer.clients[i];
                        PrintWriter TMP_OUT=new PrintWriter(TMP_SOCK.getOutputStream());
                        TMP_OUT.println(MESSAGE);
                        TMP_OUT.flush();
                    }
                }
            }
            finally{
                SOCK.close();
            }
        }
        catch(Exception X){
            System.out.print(X);
        }
    }
}