package chat.messenger;

public class ChatMessenger {

    public static void main(String[] args) {
        //Client_GUI cg = new Client_GUI();
        //Client_GUI cg = new Client_GUI();
        //Client_GUI cg1 = new Client_GUI();
    }
    
}
