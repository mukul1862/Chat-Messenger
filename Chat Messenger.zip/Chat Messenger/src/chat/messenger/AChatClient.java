package chat.messenger;

import java.io.*;
import java.lang.*;
import java.net.*;
import java.util.*;

class AChatClient implements Runnable{
    Socket SOCK;
    Scanner INPUT;
    Scanner SEND=new Scanner(System.in);
    PrintWriter OUT;
    //Client_GUI gui;
    public AChatClient(Socket X){
        this.SOCK=X;
    }
    public void run(){
        try{
            try{
                INPUT=new Scanner(SOCK.getInputStream());
                OUT=new PrintWriter(SOCK.getOutputStream());
                OUT.flush();
                CheckStream();
            }
            finally{
                SOCK.close();
            }
        }
        catch(Exception X){
            System.out.print(X);
        }
    }
    public void CheckStream(){
        while(true){
            if(INPUT.hasNext()){
                String MESSAGE=INPUT.nextLine();
                Client_GUI.jt.append(MESSAGE + "\n");
            }
        }
    }
    public void SEND(String X){
        OUT.println(Client_GUI.username+" : "+X);
        OUT.flush();

    }
}
